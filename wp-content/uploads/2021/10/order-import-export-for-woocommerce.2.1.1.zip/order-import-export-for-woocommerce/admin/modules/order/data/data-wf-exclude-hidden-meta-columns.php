<?php
// Exclude columns handled specifically
return apply_filters('hf_csv_order_exclude_meta_columns', array('wf_order_exported_status'));
 

